import React from "react";
import './Cart.css'


function Cart() {
    return (
       <>
         
       </>
    )
}

export default Cart